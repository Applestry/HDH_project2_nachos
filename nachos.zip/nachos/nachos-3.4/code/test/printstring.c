
#include "syscall.h"

int
main()
{
    PrintString("Hello");
	Halt();
	return 0;
}
