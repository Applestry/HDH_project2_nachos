#include "syscall.h"
int main(){
	PrintChar('h');
	Halt();
}