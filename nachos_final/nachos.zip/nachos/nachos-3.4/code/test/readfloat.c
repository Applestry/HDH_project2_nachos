#include "syscall.h"

int main(){
	float f;
	f = ReadFloat();
	Halt();
}