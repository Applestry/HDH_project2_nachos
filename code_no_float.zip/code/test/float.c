#include "syscall.h"
int main(){
	float* f;
	f = ReadFloat();
	PrintFloat(f);
	Halt();
}